const db = require('../database')

const model = {
	get: async () => {
		return await db.model.get('users')
	},

	insert: async (options = {}) => {
		return await db.model.insert('users', options)
	},

	update: async (options = {}, where = {}) => {
		return await db.model.update('users', options, where)
	},

	delete: async (where = {}) => {
		return await db.model.delete('users', where)
	}
}


module.exports = model