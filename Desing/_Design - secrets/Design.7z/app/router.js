//Import module "models"
const models = require('./models')

//Break the request into parameters, query and body
const parseRequest = (request) => {
	let params = request.params || {}
	const body = request.body || {}

	if (Object.keys(body).length) {
		params = Object.assign(params, body)
	}

	return {
		params: params,
		query: request.query || {}
	}
}

//Handle get users request
const getUsers = async (request, response) => {
	const result = await models.users.get();

	response.json(result)
}

const getUser = async (request, response) => {
	const {params} = parseRequest(request)
	const id = params.id || 0

	const result = await models.users.get(id);

	response.json(result)
}

//Handle post users request
const postUsers = async (request, response) => {
	const {params} = parseRequest(request)
	const result = await models.users.insert(params)

	response.json(result)
}

const postLogin = async (request, response) => {
	// const {params} = parseRequest(request)

	const data = {
		username: 'alex',
		password: 'lorem'
	}

	// verify if the user exists in the database
	const result = await models.users.get()

	// if exists => return true
	// if doesn't exist => return an error message

	response.json(result)
}

const getCollections = async (request, response) => {
	const result = await models.users.get()

	response.json(result)
}



module.exports = {
	getUsers: getUsers,
	getUser: getUser,
	postUsers: postUsers,
	postLogin: postLogin,
	getCollections: getCollections
}
