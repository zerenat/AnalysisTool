const users = require('./models/users')


module.exports = {
	users: users
}