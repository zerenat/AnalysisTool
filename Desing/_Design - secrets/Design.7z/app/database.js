const mysql = require('mysql2/promise')

const query = async (query) => {
	const connection = await mysql.createConnection({
		host: 'design-project.c88xbepvqnn0.eu-west-2.rds.amazonaws.com',
		user: 'designer',
		password: 'za9Tvt8MfcT!Qs4:',
		database: 'design'
	})

	const [result] = await connection.query(query)
	connection.end()

	return result
}

const model = {
	get: async (table) => {
		const result = await query(`SELECT * FROM ${table}`)

		return result
	},

	insert: async (table, options = {}) => {
		const keys = Object.keys(options).join(', ')
		const values = Object.values(options)
			.map(item => mysql.escape(item))
			.join(', ')

		const result = await query(`INSERT INTO ${table} (${keys}) VALUES (${values})`)

		return result.insertId
	},

	update: async (table, options = {}, where = {}) => {
		const values = Object.keys(options)
			.map(key => {
				const value = mysql.escape(options[key])
				
				return `${key} = ${value}`
			})
			.join(', ')
		const condition = Object.keys(where)
			.map(key => {
				const value = mysql.escape(where[key])
				
				return `${key} = ${value}`
			})
			.join('')

		const result = await query(`UPDATE ${table} SET ${values} WHERE (${condition})`)

		return result.affectedRows
	},

	delete: async (table, where = {}) => {
		// 
	}
}


module.exports = {
	escape: mysql.escape,
	query: query,
	model: model
}
